<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->model('Login_model');
    }

    public function index()
    {
        $this->load->view("login_view");
    }

    public function insertData()
    {
        $formData = [
            'user_name' => $this->input->post('user_name'),
            'user_email' => $this->input->post('user_email'),
            'user_password' => md5($this->input->post('user_password'))
        ];
        $this->Login_model->insertDa($formData);
        header('refresh:3;url=http://ynsmrocak.dev/welcome');
        die("3 saniye sonra anasayfaya sitesine gideceksiniz.");
    }

    public function login(){
        $var['log'] = $this->Login_model->log($this->input->post('user_name'), $this->input->post('user_password'))->row();
        if (empty($var['log'])) {
            header('refresh:1;url=http://ynsmrocak.dev');
            die("Tekrar deneyin hesap bulunmadı.");
        }else {
            $this->load->view("login_view", $var);
            header('refresh:3;url=http://ynsmrocak.dev/welcome');
            die("3 saniye sonra anasayfaya sitesine gideceksiniz.");
        }
    }
}