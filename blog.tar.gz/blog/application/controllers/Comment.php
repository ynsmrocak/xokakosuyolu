<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Comment
 * @property Comment_model Comment_model
 */
class Comment extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model("Comment_model");
    }

    public function index()
    {
        $this->load->view("comment_view");
    }

    public function insertComment(){

        $formData = $this->input->post();
        $this->Comment_model->insertComment($formData);
        header('location:' . base_url());
    }
    public function commentDetail(){

        $data['comments'] = $this->Comment_model->getComAll()->result_array();
        if (empty($data['comments'])) {
            header('location:' . base_url());
            die;
        }

        $this->load->view("post_view", $data);
    }

    public function comDelete($id) {
        $this->load->model("Comment_model");
        $this->Comment_model->comDel($id);
        header('location:' . base_url());
    }
}