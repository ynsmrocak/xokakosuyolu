<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Post
 * @property Post_model Post_model
 */
class Post extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model("Categories_model");
		$this->load->model("Post_model");
	}

	public function index()
	{
		$this->load->view("post_view");
	}

	public function editPost($id){
		$data['post'] = $this->Post_model->get($id);
		$data['cat'] = $this->Categories_model->getCatAll()->result_array();
		$this->load->view("edit_post_view",$data);
	}

	public function newPost(){
		$data['postData'] = $this->Post_model->getAll()->result_object();
		$data['cat'] = $this->Categories_model->getCatAll()->result_array();
		$this->load->view("new_post_view",$data);
	}

	public function detail($slugName){
		$this->load->model('Comment_model');

		if (empty($slugName)) {
			header('Location: /');
			die;
		}

		$data['cat'] = $this->Categories_model->getCatAll()->result_array();
		$data['post'] = $this->Post_model->getBySlugName($slugName)->row();
		$data['comments'] = $this->Comment_model->getComAll($data['post']->post_id)->result_object();
		if (empty($data['post'])) {
			header('Location: /');
			die;
		}

		$this->load->view("post_view", $data);
	}

	public function postDelete($id) {
		$this->load->model("Post_model");
		$this->Post_model->postDel($id);
		header('location:' . base_url());
	}

	public function insertPost() {
		$postData = $this->input->post();
		$this->Post_model->insertPo($postData);
		header('location:' . base_url());
	}

	public function updatePost($id)
	{
		$this->Post_model->updatePo($id);
		header('location:' . base_url());
	}
}
