<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $this->load->model('Post_model');
        $this->load->model('Categories_model');
        $data['posts'] = $this->Post_model->getAll();
        $data['categories'] = $this->Categories_model->getCatAll();

        $this->load->view('welcome_message', $data);
    }
}
