<?php

/**
 * Class Categories
 * @property Categories_model Categories_model
 */
class Categories extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model("Categories_model");
        $this->load->model("Post_model");
    }

    public function index()
    {
        $this->load->view("categories_view");
    }

    public function newCat(){
        $data['catData'] = $this->Categories_model->getCatAll();
        $this->load->view("new_cat_view",$data);
    }

    public function editCat(){
        $data['data'] = $this->Categories_model->getCatAll();
        $this->load->view("edit_cat_view",$data);
    }

    public function listCat()
    {
            $this->load->model("Categories_model");
            $data['catData'] = $this->Categories_model->getCatAll();
            $this->load->view("cat_list_view", $data);

    }

    public function lists($catName)
    {
        if (!empty($catName)) {

            $this->load->model("Categories_model");
            $data['cat'] = $this->Categories_model->getCatAll()->result_array();
            $this->load->model("Post_model");
            $data['posts'] = $this->Categories_model->lists($catName)->result_array();
            //$data['posts'] = $this->Post_model->getBySlugName($catName)->row();
            $this->load->view("categories_view", $data);
        }
    }

    public function insertCategory() {
        $catData = $this->input->post();
        $this->Categories_model->insertCat($catData);
        header('location:' . base_url());
    }

    public function catDelete($id) {
        $this->load->model("Categories_model");
        $this->Categories_model->catDel($id);
        header('location:' . base_url());
    }

    public function updateCategory($id)
    {
        $this->Categories_model->updateCat($id);
        header('location:' . base_url());
    }

}
