<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Clean Blog Post</title>
	<meta name="keywords" content="clean blog post, 2-column, multi-level, comments, html css layout" />
	<meta name="description" content="Clean Blog Post with multi-level commenting" />
	<link href="/assets/css/templatemo_style.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div id="templatemo_wrapper">

	<div id="templatemo_menu">

		<ul>
			<li><a href="index.html" class="current">Blog</a></li>
			<li><a href="portfolio.html">Portfolio</a></li>
			<li><a href="about.html">About Us</a></li>
			<li><a href="contact.html">Contact</a></li>
		</ul>

	</div> <!-- end of templatemo_menu -->

	<div id="templatemo_left_column">

		<div id="templatemo_header">

			<div id="site_title">
				<h1><a href="http://ynsmrocak.dev/welcome" target="_parent">Spor <strong>Bülteni</strong><span>Sık Sık Güncelenen Spor Sitesi</span></a></h1>
			</div><!-- end of site_title -->

		</div> <!-- end of header -->

		<div id="templatemo_sidebar">


			<h4>Spor Haberleri</h4>
			<ul class="templatemo_list">
				<?php

				foreach ($cat as $ct) {

					?>

					<li><a href="/categories/lists/<?php echo  $ct['category_slug_name'];?>"><?php echo  $ct['category_name'];?></a></li>
					<?php
				}

				?>
			</ul>

			<div class="cleaner_h40"></div>

			<h4>Ayarlar</h4>
			<ul class="templatemo_list">
				<li><a href="/categories/newCat"><?php echo "Kategori ekle"; ?></a></li>
				<li><a href="/Categories/listCat"><?php echo "Kategoriler"; ?></a></li>
			</ul>
		</div> <!-- end of templatemo_sidebar -->

	</div> <!-- end of templatemo_left_column -->

	<div id="templatemo_right_column">

		<div id="templatemo_main">

			<div class="post_section">

				<span class="comment"><a href="fullpost.html">256</a></span>

				<h2><?php echo $post->post_title;?></h2>
				<h6><?php echo $post->post_creation_date;?> | <strong>Author:</strong><?php echo $post->user_name;?> | <?php echo $post->category_name;?></h6>
				<img src="/assets/images/vakifbank-sampiyon-600_2LZ37.jpg" alt="image 1"/>
				<p><?php echo $post->post_content;?></p>
				<td><a href="/post/postDelete/<?php echo  $post->post_id;?>">Haberi Sil #</a>
					<a href="/post/editPost/<?php echo $post->post_id; ?>">Düzenle # </a>
					<a href="/post/newPost/<?php echo $post->post_id; ?>">Yeni haber ekle </a></td>
			</div>

			<div class="comment_tab"> Comments  </div>

			<?php

			if (count($comments) > 0) {

			foreach ($comments as $com) {
			//var_dump($formadata);
			//die;
			?>
			<div id="comment_section">
				<ol class="comments first_level">
					<li>
						<div class="comment_box commentbox1">
							<div class="comment_desc">
								<div> <?php echo $com->comment_creation_date;?></div>
								<div> <?php echo $com->comment_desc;?>></div>
								<div class="reply"><a href="#">Reply</a></div>
								<td><a href="/comment/comDelete/<?php echo  $com->comment_id;?>">Yorumu Sil</a></td>
							</div>
							<div class="cleaner"></div>
						</div>

					</li>

					<li>

					</li>

				</ol>
			</div>
				<?php
				}
				} else {
					?>

					<div class="comment_section">

						YORUMSUZ!

					</div>
					<?php
				}
				?>

			<div id="comment_form">
				<h3>Leave a comment</h3>

				<form action="/comment/insertComment" method="post">
					<div class="form_row">
						<label><strong>Name</strong></label>
						<br />
						<input type="hidden" name="posts_post_id" value="<?php echo $post->post_id; ?>"  />
						<input type="text" name="comment_desc" placeholder="required" />
					</div>

					<div class="form_row">
						<label><strong>Comment</strong></label>
						<br />
						<textarea  name="comment_desc" rows="" cols="" placeholder="leave a comment"></textarea>
					</div>
					<input type="submit" value="Submit" class="submit_btn" />
				</form>

			</div>

		</div> <!-- end of main -->

		<div class="cleaner"></div>
	</div>
	<!-- end of templatemo_main -->
	<div class="cleaner_h20"></div>

	<div id="templatemo_footer">

		Copyright © 2048 <a href="#">Your Company Name</a> |
		<a href="http://www.iwebsitetemplate.com" target="_parent">Website Templates</a> by <a href="http://www.templatemo.com" target="_parent">Free CSS Templates</a>

	</div>

	<div class="cleaner"></div>
</div> <!-- end of warpper -->

<div align=center>This template  downloaded form <a href='http://all-free-download.com/free-website-templates/'>free website templates</a></div></body>
</html>