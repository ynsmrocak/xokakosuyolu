<!DOCTYPE html>
<html>
<head>
    <title>Giriş Paneli</title>
</head>
<body>
<style type="text/css">
    .tum {width:100%; background:#f59e00; float:inherit;}
    .sol {width:50%; background:#666; float:left;}
    .sag {width:50%; background:#03C; float:right;}
</style>
<div><div></div>
    <div id="site_title" class="tum" >
        <h1><a href="http://ynsmrocak.dev/welcome" target="_parent"><strong>Spor Bülteni Sık Sık Güncelenen Spor Sitesi</strong></a></h1>
    </div>
</div>
<div class="sol">
    <form action="/login/login" method="post">
<h3>Giriş Paneli</h3>
<label for="username">Username:</label>
<input type="text" size="20" id="username" name="user_name" placeholder="username"/>
<br/>
<label for="password">Password:</label>
<input type="password" size="20" id="userpassword" name="user_password" placeholder="password"/>
<br/>
<input type="submit" value="Login"/>
</div>
</form>
<div class="sag">
    <html>
    <body>
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <?php echo $this->session->flashdata('verify_msg'); ?>
            </div>
        </div>
        <form action="/login/insertData" method="post">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3>Kullanıcı Kayıt</h3>
                    </div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label for="name">Name:</label>
                            <input class="form-control" name="user_name" placeholder="Your Name" type="text" />
                            <span class="text-danger"></span>
                        </div>

                        <div class="form-group">
                            <label for="email">Email ID:</label>
                            <input class="form-control" name="user_email" placeholder="Email-ID" type="text" />
                            <span class="text-danger"></span>
                        </div>

                        <div class="form-group">
                            <label for="subject">Password:</label>
                            <input class="form-control" name="user_password" placeholder="Password" type="password" />
                            <span class="text-danger"></span>
                        </div>

                        <div class="form-group">
                            <input type="submit" value="Submit" class="submit_btn" />
                        </div>
                        <?php echo $this->session->flashdata('msg'); ?>
                    </div>
                </div>
            </div>
        </div>
        </form>
    </div>
    </body>
    </html>
</div>
</body>
</html>