<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Clean Blog Template</title>
    <meta name="keywords" content="clean blog template, html css layout" />
    <meta name="description" content="Clean Blog Template is provided by templatemo.com" />
    <link href="/assets/css/templatemo_style.css" rel="stylesheet" type="text/css" />
    <link href="/assets/css/s3slider.css" rel="stylesheet" type="text/css" />
    <!-- JavaScripts-->
    <script type="text/javascript" src="/assets/js/jquery.js"></script>
    <script type="text/javascript" src="/assets/js/s3Slider.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#slider').s3Slider({
                timeOut: 1600
            });
        });
    </script>

</head>
<body>

<div id="templatemo_wrapper">

    <div id="templatemo_menu">

        <ul>
            <li><a href="index.html" class="current">Blog</a></li>
            <li><a href="portfolio.html">Portfolio</a></li>
            <li><a href="about.html">About Us</a></li>
            <li><a href="contact.html">Contact</a></li>
        </ul>

    </div> <!-- end of templatemo_menu -->

    <div id="templatemo_left_column">

        <div id="templatemo_header">

            <div id="site_title">
                <h1><a href="http://ynsmrocak.dev/welcome" target="_parent">Spor <strong>Bülteni</strong><span>Sık Sık Güncelenen Spor Sitesi</span></a></h1>
            </div><!-- end of site_title -->

        </div> <!-- end of header -->

        <div id="templatemo_sidebar">

            <h4>Spor Haberleri</h4>
            <ul class="templatemo_list">
                <?php

                if (count($cat) > 0) {

                    foreach ($cat as $value) {
                        ?>
                        <li><a href="/categories/lists/<?php echo  $value['category_slug_name'];?>"><?php echo  $value['category_name'];?></a></li>
                        <?php
                    }
                    ?>
                <?php } else {
                    ?>
                    <div class="post_section">
                        Yazı bulunamadı!
                    </div>
                    <?php
                }
                ?>
            </ul>
            <div class="cleaner_h40"></div>
            <h4>Ayarlar</h4>
            <ul class="templatemo_list">
                <li><a href="/Categories/newCat"><?php echo "Kategori ekle"; ?></a></li>
                <li><a href="/Categories/listCat"><?php echo "Kategoriler"; ?></a></li>
            </ul>
        </div> <!-- end of templatemo_sidebar -->

    </div> <!-- end of templatemo_left_column -->

    <div id="templatemo_right_column">

        <div id="templatemo_main">

            <div id="category_form">
                <h1>New Post</h1>

                <form action="/Post/insertPost" method="post">

                    <div class="form_row">
                        <label><strong>User</strong></label>
                        <br />
                        <input type="text" name="users_user_id" size="65"  placeholder="required"  />
                    </div>

                    <div class="form_row">
                        <label><strong>Category</strong></label>
                        <br />


                        <?php

                        if (count($cat) > 0) {

                            foreach ($cat as $value) {
                                ?>
                                <input type="radio" name="categories_category_id" value="<?php echo $value['category_id'] ?>" /><?php echo $value['category_name']; ?>
                                <?php
                            }
                            ?>
                                <?php } else {
                            ?>
                            <div class="post_section">
                                Yazı bulunamadı!
                            </div>
                            <?php
                        }
                        ?>


                    </div>

                    <div class="form_row">
                        <label><strong>Status</strong></label>
                        <br />
                        <input type="radio" name="post_status" size="65" value="1"  /><?php echo "Yayında"; ?>
                        <input type="radio" name="post_status" size="65" value="0"  /><?php echo "Yayında değil"; ?>


                    </div>

                    <div class="form_row">
                        <label><strong>Title</strong></label>
                        <br />
                        <input type="text" name="post_title" size="65"  placeholder="required"  />
                    </div>

                    <div class="form_row">
                        <label><strong>Content</strong></label>
                        <br />
                        <input type="text" name="post_content" size="65" placeholder="required"  />
                    </div>


                    <div class="form_row">
                        <label><strong>Slug Name</strong></label>
                        <br />
                        <input type="text" name="post_slug_name" size="65" placeholder="required" />
                    </div>

                    <div class="form_row">
                        <label><strong>Creation Date</strong></label>
                        <br />
                        <input type="date" data-date="" data-date-format="" value=""/>
                    </div>
                    <input type="submit" value="Submit" class="submit_btn" />
                </form>

            </div>

            <div class="cleaner"></div>
        </div>
        <!-- end of templatemo_main -->
        <div class="cleaner_h20"></div>


        <div class="cleaner"></div>
    </div> <!-- end of warpper -->

</body>
</html>