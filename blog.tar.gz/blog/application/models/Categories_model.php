<?php
class Categories_model extends CI_Model{

    /**
     * Post constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function getAll()
    {
        $this->db->select("*");
        $this->db->order_by("category_id", "DESC");
        return $this->db->get('categories');
    }

    public function getCatAll(){
        $this->db->select("*");
        return $this->db->get('categories');
    }

    public function getByCatName($catName){
        $this->db->select("*");
        $this->db->where("category_name", $catName);
        return $this->db->get('categories');
    }

    public function lists($catName){
        $this->db->select("*");
        $this->db->from('categories c');
        $this->db->join('posts p', 'c.category_id = p.categories_category_id', 'INNER');
        $this->db->join('users u', 'u.user_id = p.users_user_id', 'INNER');
        $this->db->where("category_slug_name", $catName);
        //var_dump($this->db->get()->result_array());
        //die;
        return $this->db->get();
    }

    public function insertCat($catData)
    {
        $this->db->insert('categories', $catData);
    }

    public function catDel($id){
        $this->db->delete('categories', array('category_id'=>$id));
    }

    public function updateCat($id){
        $this->db->where('category_id', $id);
        $this->db->update('categories', $this->input->post());
    }
}