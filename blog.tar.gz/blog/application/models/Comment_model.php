<?php
class Comment_model extends CI_Model{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function insertComment($formData)
    {
        $this->db->insert('comment', $formData);
    }

    public function getComAll($postID){
        $this->db->select("*");
        $this->db->from('comment co');
        $this->db->where('co.posts_post_id',$postID);
        //$this->db->join('users u', 'u.user_id = co.users_user_id', 'INNER');
        return $this->db->get();
    }

    public function comDel($id){
        $this->db->delete('comment', array('comment_id'=>$id));
    }
}