<?php
class Login_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function insertDa($formData)
    {
        $this->db->insert('users', $formData);
    }

    function log($username, $password)
    {
        $this -> db -> from('users');
        $this -> db -> select('user_name, user_password');
        $this -> db -> where('user_name', $username);
        $this -> db -> where('user_password', MD5($password));
        $this -> db -> limit(1);
        return $this -> db -> get();
    }
}