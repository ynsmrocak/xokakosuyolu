<?php
class Post_model extends CI_Model{

    /**
     * Post constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function getAll()
    {
        $this->db->select("*");
        $this->db->from('posts p');
        $this->db->join("users u", "u.user_id = p.users_user_id", "INNER");
        $this->db->join("categories c", "c.category_id = p.categories_category_id", "INNER");
        $this->db->order_by("post_id", "DESC");
        return $this->db->get();
    }

    public function get($id){

        return $this->db->where('post_id',$id)->get('posts')->row_object();
    }

    public function getBySlugName($slugName)
    {
        $this->db->select("*");
        $this->db->where("post_slug_name", $slugName);
        $this->db->from('posts p');
        $this->db->join('users u', 'u.user_id = p.users_user_id', 'INNER');
        $this->db->join('categories c', 'c.category_id = p.users_user_id', 'INNER');
        return $this->db->get();
    }

    public function postDel($id){
        $this->db->delete('posts', array('post_id'=>$id));
    }

    public function insertPo($postData)
    {
        //var_dump($postData); die;
        $this->db->insert('posts', $postData);
    }

    public function updatePo($id){
        $this->db->where('post_id', $id);
        $this->db->update('posts', $this->input->post());
    }
}