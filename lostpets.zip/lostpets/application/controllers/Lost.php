<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lost extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model("Lost_model");
    }

    public function index()
    {
        $this->load->view('lost_view');
    }
}
